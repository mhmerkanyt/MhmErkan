# InsFollow
<p align="center">
  <img src="https://1.bp.blogspot.com/-8J6nXMm4Fn4/X1nN5SrLvkI/AAAAAAAAAQ0/J8TNfruwGEgiAfOKxIiRD_q3dKOGUl-XQCLcBGAsYHQ/s530/Screenshot_20200910_122015.png" width="470" height="250">
</p>
Best Tool For Increase Instagram Follower.

## Requirements
1. openssl
2. curl

## How to Install in Termux

`$ pkg up -y`

`$ pkg install openssl-tool`

`$ pkg install curl`

`$ pkg install git`

`$ git clone https://github.com/termuxprofessor/insfollow`

`$ cd insfollow`

`$ chmod +x insfollow.sh`

`$ termux-wake-lock`

`$ bash insfollow.sh`

## • Watch Video Tutorial From Below
* https://youtu.be/SAkFZJRaq0U
---

<p align="center">
  Follow Me On
</p>
<p align="center">
  <a href="https://www.youtube.com/c/TermuxProfessorYT">
    <img src="https://github.com/th3unkn0n/extra/blob/master/.img/yt.png" width="40" height="40">
  </a>
  <a href="https://www.instagram.com/termuxprofessor/">
    <img src="https://github.com/th3unkn0n/extra/blob/master/.img/ig.png" width="40" height="40">
</p>
